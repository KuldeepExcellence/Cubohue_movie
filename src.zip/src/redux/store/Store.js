import { createStore } from "redux";
import { Reducers } from "../reducer/Reducers";

 export const mystore=createStore(Reducers);