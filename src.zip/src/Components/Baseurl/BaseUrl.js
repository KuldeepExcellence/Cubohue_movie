

 export const TmdbKey='b009a5b354a9ce6700d2cc61a900387b';

 export const URL ='https://image.tmdb.org/t/p/w500'